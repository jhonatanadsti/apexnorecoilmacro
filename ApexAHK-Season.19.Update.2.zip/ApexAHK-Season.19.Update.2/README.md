# ApexAHK
Reduced/No Recoil Script For Apex Legos

**For Educational Purposes ONLY**

UPDATE Log

**11/03/2023**
- Updated all patterns for Season 19
- Improved mouseWheel scrolling detection
- Moved LSTAR to Energy Tier
- Moved Wingman to Red Tier
- Added More Buttons to toggle weapon searches, Should be much more consistent.

**08/20/2023**
- Updated all patterns for Season 18
- Fixed Sella
- Fixed Autofire
- Fixed Scrolling to Cycle Weapon Detection   


**Known Issues**
- Hemlok Doesn't Detect
- Prowler pattern missing for FullAUTO (Burst mode works fine, Please toggle to burst or disable)

**NOTES**
I am not the original creator of this script, this is a FORK, 
Refer to https://www.unknowncheats.me/forum/apex-legends/466312-ahk-reduce-recoil-script-auto-detect-weapon.html 
For Original Skript
